﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using AgendaWpPanorama.Controller;
using AgendaWpPanorama.Model;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace AgendaWpPanorama
{
    public partial class Edicao : PhoneApplicationPage
    {

        #region Variáveis
        ParametrosConexao Objeto = new ParametrosConexao();
        dispesa DispesaFinaceira = new dispesa();
        #endregion

        public Edicao()
        {
            InitializeComponent();
            try
            {
                CarregarPagina();
            }
            catch (Exception)
            {
                MessageBox.Show("Registro não encontrado");
                NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));
            }

        }

        private void Salvar_Click(object sender, EventArgs e)
        {

            if (String.IsNullOrEmpty(Nome.Text))
            { MessageBox.Show("Informe um Nome!"); return; }

            if (String.IsNullOrEmpty(Valor.Text))
            { MessageBox.Show("Informe um Valor!"); return; }


            try
            {
                Alterar();

            }
            catch (Exception)
            {

                MessageBox.Show("Ocorreu algum erro para salvar!");
            }

        }

        private void Deletar_Click(object sender, EventArgs e)
        {
            MessageBoxResult m = MessageBox.Show("Deseja Excluir?", "Excluir", MessageBoxButton.OKCancel);
            if (m != MessageBoxResult.Cancel)
            {
                try
                {
                    Excluir();

                }
                catch (Exception)
                { MessageBox.Show("Ocorreu erro ao tentar deletar"); }

            }
        }

        private void Voltar_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }

        public async void Excluir()
        {
            Objeto.dispesa.Id = DispesaFinaceira.Id;
            var jsonString = HelperComuns.Serialize(Objeto.dispesa);
            var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await Objeto._client.PostAsync(Objeto.ServiceUrl + "ExcluirDispesas", content);
            var Retorno = response.Content.ReadAsStringAsync();

            string AguardRetorno = await Retorno;
            Objeto.Log = JsonConvert.DeserializeObject<LogTransacao>(AguardRetorno);

            MessageBox.Show(Objeto.Log.NomeTipoLog);
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));

        }

        public async void Alterar()
        {
            dispesa objeto = new dispesa();

            objeto.Id = DispesaFinaceira.Id;

            var Dia = MinhaData.Value.Value.Day;

            var Mes = MinhaData.Value.Value.Month;

            var Ano = MinhaData.Value.Value.Year;

            string dataValida = Ano + "-" + Mes + "-" + Dia;

            objeto.NomeDispesa = Nome.Text;
            objeto.DataDispesa = dataValida;
            if (String.IsNullOrEmpty(Observacao.Text))
            { objeto.ObservacaoDispesa = Nome.Text; }
            else
                objeto.ObservacaoDispesa = Observacao.Text;

            objeto.ValorDispesa = Convert.ToDecimal(Valor.Text);

            var jsonString = HelperComuns.Serialize(objeto);
            var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await Objeto._client.PostAsync(Objeto.ServiceUrl + "AlterarDispesa", content);
            var Retorno = response.Content.ReadAsStringAsync();

            string AguardRetorno = await Retorno;
            Objeto.Log = JsonConvert.DeserializeObject<LogTransacao>(AguardRetorno);

            MessageBox.Show(Objeto.Log.NomeTipoLog);
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private int parameter;

        public int Parameter
        {
            get { return parameter; }
            set { parameter = value; }
        }

        private int Id;

        public int ID
        {
            get { return Id; }
            set { Id = value; }
        }

        //preenche entidade e retrna
        public dispesa RetornaItem()
        {
            return DispesaFinaceira;
        }

        // carregar campos 
        public void CarregaCampos(dispesa Item)
        {
           
            Id = Item.Id;
            Nome.Text = Item.NomeDispesa;
            MinhaData.Value = Convert.ToDateTime(Item.DataDispesa);
            Valor.Text = Item.ValorDispesa.ToString();
            Observacao.Text = Item.ObservacaoDispesa;
        }

        public async void CarregarPagina()
        {
            try
            {
                if (Internal.Parametro != null)
                    parameter = Internal.Parametro;
                else
                    NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));

                if (parameter != null)
                {
                    DataControl controle = new DataControl();
                    DataItem Item = new DataItem();
                    int Id = parameter;

                    var ObjetoRetorno = await ObterDispesas(new dispesa { Id = Id });

                    DispesaFinaceira = ObjetoRetorno;

                    CarregaCampos(ObjetoRetorno);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Registro não encontrado");
                NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));
            }



        }

        public async Task<dispesa> ObterDispesas(dispesa dispesa)
        {

            HttpResponseMessage response = new HttpResponseMessage();

            var jsonStringEnvio = HelperComuns.Serialize(dispesa);

            var content = new StringContent(jsonStringEnvio, Encoding.UTF8, "application/json");
            response = await Objeto._client.PostAsync(Objeto.ServiceUrl + "ObterDispesa", content);

            var jsonString = await response.Content.ReadAsStringAsync();

            var Retorno = JsonConvert.DeserializeObject<DispesaRetorno>(jsonString);

            return Retorno;

        }

    }
}