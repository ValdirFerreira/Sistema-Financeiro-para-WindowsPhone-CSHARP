﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgendaWpPanorama.Model
{
    public class Internal
    {
        protected static int parametro;

        public static int Parametro

        { get { return parametro; } set { parametro = value; } }

    }
}
