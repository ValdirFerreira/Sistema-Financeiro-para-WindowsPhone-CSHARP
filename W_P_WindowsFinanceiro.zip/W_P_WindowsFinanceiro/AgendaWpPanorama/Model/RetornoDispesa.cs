﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgendaWpPanorama.Model
{
    public class RetornoDispesa
    {
        public int Id { get; set; }
        public string NomeDispesa { get; set; }
        public DateTime DataDispesa { get; set; }
        public decimal ValorDispesa { get; set; }
        public string ObservacaoDispesa { get; set; }
        public int CodigoLog { get; set; }
        public string NomeTipoLog { get; set; }
    }
}
