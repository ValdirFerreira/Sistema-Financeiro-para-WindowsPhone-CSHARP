﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgendaWpPanorama.Model
{
    [Table(Name="tdDataItem")]
    public class DataItem
    {
        [Column(Name = "Id", IsPrimaryKey = true, IsDbGenerated = true, CanBeNull = false, AutoSync = AutoSync.OnInsert,DbType="Int NOT NULL IDENTITY")]
        public int Id { get; set; }
        [Column(Name="Titulo",CanBeNull=false)]
        public string Titulo { get; set; }
         [Column(Name = "Conteudo", CanBeNull = false)]
        public string Conteudo { get; set; }
    }
}
