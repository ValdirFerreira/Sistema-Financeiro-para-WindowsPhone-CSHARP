﻿using Microsoft.Phone.Net.NetworkInformation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;


namespace AgendaWpPanorama.Model
{
    public class ParametrosConexao
    {
        public ParametrosConexao()
        {
            
            _client = new HttpClient();
            Log = new LogTransacao();
            dispesa = new dispesa();

            if (DeviceNetworkInformation.IsWiFiEnabled)
            {
                ServiceUrl = "http://192.168.0.101:8090/api/Financeiro/";
            }
            else
            {
                ServiceUrl = "http://177.141.41.150:8090/api/Financeiro/";
            }

            //  ServiceUrl = "http://servidorcamarada.ddns.net/api/Financeiro/";
            jsonStringEnt = HelperComuns.Serialize(dispesa);
            content = new StringContent(jsonStringEnt, Encoding.UTF8, "application/json");
        }

        public string ServiceUrl { get; set; }

        public string jsonStringEnt { get; set; }

        public StringContent content { get; set; }

        public dispesa dispesa { get; set; }
        public HttpClient _client { get; set; }
        public LogTransacao Log { get; set; }


    }
}
