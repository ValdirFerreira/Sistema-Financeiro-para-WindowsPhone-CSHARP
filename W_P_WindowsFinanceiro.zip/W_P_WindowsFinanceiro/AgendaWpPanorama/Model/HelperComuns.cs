﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace AgendaWpPanorama.Model
{
    public static class HelperComuns
    {
        public static string Serialize(dispesa dispesa)
        {
            var jsonSerializer = CreateDataContractJsonSerializer(typeof(dispesa));
            byte[] streamArray = null;
            using (var memoryStream = new MemoryStream())
            {
                jsonSerializer.WriteObject(memoryStream, dispesa);
                streamArray = memoryStream.ToArray();
            }
            string json = Encoding.UTF8.GetString(streamArray, 0, streamArray.Length);
            return json;
        }

        public static DataContractJsonSerializer CreateDataContractJsonSerializer(Type type)
        {
            const string dateFormat = "yyyy-MM-ddTHH:mm:ss.fffffffZ";
            var settings = new DataContractJsonSerializerSettings
            {
                DateTimeFormat = new DateTimeFormat(dateFormat)
            };
            var serializer = new DataContractJsonSerializer(type, settings);
            return serializer;
        }
    }
}
