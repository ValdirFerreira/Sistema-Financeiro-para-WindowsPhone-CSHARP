﻿using AgendaWpPanorama.DAO;
using AgendaWpPanorama.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgendaWpPanorama.Controller
{
   public class DataControl
    {

        public void CreateDataBase()
        {
            Provider.CreateDataBase();
        }

        public IEnumerable<DataItem> GetDataItem()
        {
            return Provider.GetDataItems();
        }

        internal void Salvar(DataItem Item)
        {
            Provider.Salvar(Item);
        }

        internal void Alterar(DataItem item)
        {
            Provider.Alterar(item);
        }

        internal void Remove(DataItem Item)
        {

            Provider.Remover(Item);
        }

        public DataItem SelecionaItem(string Titulo)
        {
            return Provider.SelecionaItem(Titulo);
        }

        public DataItem SelecionaItemId(int Id)
        {
            return Provider.SelecionaItemId(Id);
        }
    
    }
}
