﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using AgendaWpPanorama.Resources;
using AgendaWpPanorama.Controller;
using AgendaWpPanorama.Model;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Net.Http;
using Newtonsoft.Json;
using System.IO;
using System.Text;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace AgendaWpPanorama.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public MainViewModel()
        {
            this.Items = new ObservableCollection<ItemViewModel>();
        }

        /// <summary>
        /// A collection for ItemViewModel objects.
        /// </summary>
        public ObservableCollection<ItemViewModel> Items { get; private set; }

        private string _sampleProperty = "Sample Runtime Property Value";
        /// <summary>
        /// Sample ViewModel property; this property is used in the view to display its value using a Binding
        /// </summary>
        /// <returns></returns>
        public string SampleProperty
        {
            get
            {
                return _sampleProperty;
            }
            set
            {
                if (value != _sampleProperty)
                {
                    _sampleProperty = value;
                    NotifyPropertyChanged("SampleProperty");
                }
            }
        }

        /// <summary>
        /// Sample property that returns a localized string
        /// </summary>
        public string LocalizedSampleProperty
        {
            get
            {
                return AppResources.SampleProperty;
            }
        }

        public bool IsDataLoaded
        {
            get;
            private set;
        }

        /// <summary>
        /// Creates and adds a few ItemViewModel objects into the Items collection.
        /// </summary>
        public void LoadData()
        {
            CarregarLista();
            this.IsDataLoaded = true;
        }

        /// <summary>
        /// Customizações 
        /// </summary>
        public async void CarregarLista()
        {
            try
            {
                var Lista = await ListarDispesas();

                foreach (var ListaItens in Lista)
                {
                    this.Items.Add(new ItemViewModel() { Id = ListaItens.Id, Titulo = ListaItens.NomeDispesa, Conteudo = ListaItens.ValorDispesa.ToString() });
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show("Erro ao tentar carregar a lista");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<DispesaRetorno>> ListarDispesas()
        {

            ParametrosConexao Objeto = new ParametrosConexao();
            HttpResponseMessage response = await Objeto._client.PostAsync(Objeto.ServiceUrl + "ListaDispesas", Objeto.content);
            var jsonString = await response.Content.ReadAsStringAsync();
            var ListARetorno = JsonConvert.DeserializeObject<DispesaRetorno[]>(jsonString);

            return ListARetorno;
        }


        /// <summary>
        /// 
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="propertyName"></param>
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}