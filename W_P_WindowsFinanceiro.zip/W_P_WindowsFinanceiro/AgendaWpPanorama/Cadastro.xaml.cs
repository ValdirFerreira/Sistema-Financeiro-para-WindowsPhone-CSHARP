﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using AgendaWpPanorama.Controller;
using AgendaWpPanorama.Model;
using System.IO;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;
using System.Text;

namespace AgendaWpPanorama
{
    public partial class Cadastro : PhoneApplicationPage
    {
        #region Variáveis
        ParametrosConexao Objeto = new ParametrosConexao();
        #endregion

        public Cadastro()
        {
            InitializeComponent();
        }

        private void Salvar_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Nome.Text))
            { MessageBox.Show("Informe um Nome!"); return; }

            if (String.IsNullOrEmpty(Valor.Text))
            { MessageBox.Show("Informe um Valor!"); return; }



            try
            {
                Salvar();

            }
            catch (Exception)
            {

                MessageBox.Show("Ocorreu algum erro para salvar!");
            }

        }

        private void Deletar_Click(object sender, EventArgs e)
        {

        }

        private void Voltar_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }

        public async void Salvar()
        {

            dispesa objeto = new dispesa();

            var Dia = MinhaData.Value.Value.Day;

            var Mes = MinhaData.Value.Value.Month;

            var Ano = MinhaData.Value.Value.Year;

            string dataValida = Ano + "-" + Mes + "-" + Dia;

            objeto.NomeDispesa = Nome.Text;
            objeto.DataDispesa = dataValida;
            if (String.IsNullOrEmpty(Observacao.Text))
            { objeto.ObservacaoDispesa = Nome.Text; }
            else
                objeto.ObservacaoDispesa = Observacao.Text;

            objeto.ValorDispesa = Convert.ToDecimal(Valor.Text);

            var jsonString = HelperComuns.Serialize(objeto);
            var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await Objeto._client.PostAsync(Objeto.ServiceUrl + "SalvarDispesa", content);
            var Retorno = response.Content.ReadAsStringAsync();

            string AguardRetorno = await Retorno;
            Objeto.Log = JsonConvert.DeserializeObject<LogTransacao>(AguardRetorno);

            MessageBox.Show(Objeto.Log.NomeTipoLog);
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));

        }



    }
}