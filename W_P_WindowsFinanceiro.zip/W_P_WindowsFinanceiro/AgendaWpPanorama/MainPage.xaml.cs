﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using AgendaWpPanorama.ViewModels;
using AgendaWpPanorama.Model;
using System.Threading.Tasks;

using System.IO;
using System.Text;
using System.Runtime.Serialization.Json;
using Newtonsoft.Json;
using System.Net.Http;

namespace AgendaWpPanorama
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            // Set the data context of the listbox control to the sample data
            DataContext = App.ViewModel;

            CarregaLista();
        }

        public void CarregaLista()
        {
            App.ViewModel.Items.Clear();
            App.ViewModel.LoadData();
        }

        // Load data for the ViewModel Items
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Lista_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count.Equals(1) && e.AddedItems[0] != null)
            {
                // Objeto selecionado.
                var ItemSelecionado = (ItemViewModel)((LongListSelector)sender).SelectedItem;

                Uri uri = new Uri("/Edicao.xaml", UriKind.RelativeOrAbsolute);
                Internal.Parametro = ItemSelecionado.Id;
                this.NavigationService.Navigate(uri);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NovoBloco_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Cadastro.xaml", UriKind.Relative));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Sobre_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Sobre.xaml", UriKind.Relative));
        }

        private void Atualizar_Click(object sender, EventArgs e)
        {
            CarregaLista();
        }
        
    }
}