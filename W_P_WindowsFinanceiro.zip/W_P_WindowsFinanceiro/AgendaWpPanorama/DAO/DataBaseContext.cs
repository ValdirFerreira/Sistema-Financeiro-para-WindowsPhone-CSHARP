﻿using AgendaWpPanorama.Model;
using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgendaWpPanorama.DAO
{
    public class DataBaseContext : DataContext
    {
        public static string ConnectionString = "Data Source=isostore:/ToDo.sdf";   //"C:/Projetos/WindowsPhoneAgenda/BaseMyDatabase#1.sdf"; 

        private Table<DataItem> _dataItem;

        public Table<DataItem> DataItem
        {
            get
            {

                if (this._dataItem == null)
                    this._dataItem = this.GetTable<DataItem>();

                return this._dataItem;
            }

        }

        public DataBaseContext(string connectionString)
            : base(connectionString)
        {

        }
    }
}
