﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AgendaWpPanorama.Model;

namespace AgendaWpPanorama.DAO
{
    public class Provider
    {
        public static void CreateDataBase()
        {
            using (DataBaseContext db = new DataBaseContext(DataBaseContext.ConnectionString))
            {
                if (!db.DatabaseExists())
                    db.CreateDatabase();
            }
        }

        public static IEnumerable<DataItem> GetDataItems()
        {
            List<DataItem> returnValu = null;

            returnValu = new List<DataItem>();

            using (DataBaseContext db = new DataBaseContext(DataBaseContext.ConnectionString))
            {
                var query = db.DataItem.OrderBy(d => d.Id);

                foreach (DataItem item in query)
                {
                    returnValu.Add(item);
                }
            }
            return returnValu;
        }

        public static DataItem SelecionaItem(string Titulo)
        {

            DataItem Item = new DataItem();
            using (DataBaseContext db = new DataBaseContext(DataBaseContext.ConnectionString))
            {
                Item = (from ord in db.GetTable<DataItem>()
                        where (ord.Titulo == Titulo)
                        select ord).SingleOrDefault<DataItem>();

            }

            return Item;
        }

        public static DataItem SelecionaItemId(int Id)
        {

            DataItem Item = new DataItem();
            using (DataBaseContext db = new DataBaseContext(DataBaseContext.ConnectionString))
            {
                Item = (from ord in db.GetTable<DataItem>()
                        where (ord.Id == Id)
                        select ord).SingleOrDefault<DataItem>();

            }

            return Item;
        }


        internal static void Salvar(Model.DataItem novoItem)
        {
            using (DataBaseContext db = new DataBaseContext(DataBaseContext.ConnectionString))
            {
                db.DataItem.InsertOnSubmit(novoItem);
                db.SubmitChanges();
            }
        }

        internal static void Alterar(Model.DataItem Item)
        {
            using (DataBaseContext db = new DataBaseContext(DataBaseContext.ConnectionString))
            {


                DataItem item = (from c in db.DataItem
                                 where c.Id == Item.Id
                                 select c).Single();


                item.Titulo = Item.Titulo;
                item.Conteudo = Item.Conteudo;


                db.SubmitChanges();
            }
        }

        internal static void Remover(Model.DataItem item)
        {

            using (DataBaseContext db = new DataBaseContext(DataBaseContext.ConnectionString))
            {
                var query = db.DataItem.Where(d => d.Id == item.Id);

                if (query.Count() > 0)
                {

                    db.DataItem.DeleteOnSubmit(query.First());

                    db.SubmitChanges();
                }

            }

        }
    }
}
